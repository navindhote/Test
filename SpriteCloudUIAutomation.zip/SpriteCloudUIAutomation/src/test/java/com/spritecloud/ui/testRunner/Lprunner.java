package com.spritecloud.ui.testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;

import io.cucumber.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"Features"},
		glue={"com.spritecloud.ui.stepDefinations.sub"},
		monochrome = true, tags="@Navin",
		plugin = {"pretty","html:target/reports/report.html"}
		
		)
public class Lprunner {

}
