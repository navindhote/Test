import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

public class TokenizedAuthorization2 {
	
	@Test
	public String generateToken() {
		
		
		RestAssured.baseURI="https://bookstore.toolsqa.com/";
		
		String R=given().log().all().header("Content-Type","application/json").
body("{\r\n"
		 		+ "  \"userName\": \"Prathmesh5\",\r\n"
		 		+ "  \"password\": \"Velocity@1235\"\r\n"
		 		+ "}").when().post("/Account/v1/GenerateToken")
 .then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		
		JsonPath J=new JsonPath(R);
		String T=J.getString("token");
		System.out.println(T);	
		
		return T;
		
	}
	
	
	@Test
	public void bookAdd() {
		
		TokenizedAuthorization2 TA= new TokenizedAuthorization2();
		
		
		RestAssured.baseURI="https://bookstore.toolsqa.com/";
		
		given().log().all().header("Content-Type","application/json").header("Authorization","Bearer "+ TA.generateToken()).body("{\r\n"
				+ "  \"userId\": \"925fd8b6-5348-45af-97cb-64b3f2b28c48\",\r\n"
				+ "  \"collectionOfIsbns\": [\r\n"
				+ "    {\r\n"
				+ "      \"isbn\": \"9781449331818\"\r\n"
				+ "    }\r\n"
				+ "  ]\r\n"
				+ "}").when().post("/BookStore/v1/Books").then().log().all().assertThat().statusCode(201);		
		
	}
	
	
	

}
