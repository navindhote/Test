
public class pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=1;i<=3;i++) {
			
			for(int j=1;j<=i;j++) {
				
                 if (j>1) {
					
					for(int k=4;k>5-j;k--) {
						
						System.out.print(i+k);
					}
					
				      }else {
                 
				System.out.print(i);
				      }
				
				
			}
			System.out.println();
			
			
		}

	}

}
