import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Request1 {
	
	
//	@Test
//	public void getrequest() {
//		
//		
//		RestAssured.baseURI="https://reqres.in/";
//		
//		String R= given().log().all().header("Content-Type","application/json").
//		when().get("api/users?page=2").
//		then().log().all().assertThat().statusCode(200).body("page", equalTo(2)).extract().response().asString();
//		
//	
//	}
	
//	@Test
//	public void postRequest() {
//		
//		RestAssured.baseURI="https://reqres.in/";
//		 String R=given().log().all().header("Content-Type","application/json").body("{\r\n"
//		 		+ "    \"name\": \"morpheus\",\r\n"
//		 		+ "    \"job\": \"leader\"\r\n"
//		 		+ "}")
//		 .when().post("/api/users").
//		 then().log().all().assertThat().statusCode(201).body("name", equalTo("morpheus")).extract().response().asString();
//         System.out.println("------------------------------");
//         System.out.println(R);	
//	}
	
	@Test
	public void putRequest() {
		
		RestAssured.baseURI="https://reqres.in/";
		
	String	R=given().log().all().header("Content-Type","application/json").body("{\r\n"
		 		+ "    \"name\": \"morpheus\",\r\n"
		 		+ "    \"job\": \"zion resident\"\r\n"
		 		+ "}")
		.when().put("/api/users/2").
		then().log().all().assertThat().statusCode(200).body("job", equalTo("zion resident")).extract().response().asString();
		System.out.println(R);	

		JsonPath J=new JsonPath(R);
		String r=J.getString("job");
		System.out.println(r);
		Assert.assertEquals(r, "zion resident");			
	}
	
//	@Test
//	public void deleteRequest() {
	
	
	
//		RestAssured.baseURI="https://reqres.in/";
//		
//		given().log().all().header("Content-Type","application/json")
//		.when().delete("/api/users/2").
//		then().log().all().assertThat().statusCode(204);
//		
//	}
	
@Test
	public void basicauth() {		
		RestAssured.baseURI="https://postman-echo.com/";		
		given().log().all().header("Content-Type","application/json").auth().preemptive().basic("postman", "password")
		.when().get("/basic-auth").
		then().log().all().assertThat().statusCode(200);		
	}
	
	
	


}
