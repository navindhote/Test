import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class TokenizedAuthorization1 {
	
	@Test
	public String tokenGenaration() {
		
		RestAssured.baseURI="https://bookstore.toolsqa.com/";
		
		String R=given().log().all().header("Content-Type","application/json").body("{\r\n"
		 		+ "  \"userName\": \"Prathmesh4\",\r\n"
		 		+ "  \"password\": \"Velocity@1235\"\r\n"
		 		+ "}").
		when().post("/Account/v1/GenerateToken").
		then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath J=new JsonPath(R);
		String T=J.getString("token");
		System.out.println(T);
		
		return T;
		
	}
	
	
	@Test 
	public void recordcreation() {
		
		RestAssured.baseURI="https://bookstore.toolsqa.com/";
		TokenizedAuthorization TA=new TokenizedAuthorization();
//		System.out.println(TA.generateToken());
		String R=given().log().all().header("Content-Type","application/json").header("Authorization","Bearer "+TA.generateToken()).body("{\r\n"
				+ "  \"userId\": \"9df10c10-1df3-4cfd-afc6-364caa38da59\",\r\n"
				+ "  \"collectionOfIsbns\": [\r\n"
				+ "    {\r\n"
				+ "      \"isbn\": \"9781449331818\"\r\n"
				+ "    }\r\n"
				+ "  ]\r\n"
				+ "}")
		 .when().post("/BookStore/v1/Books").
		 then().log().all().assertThat().statusCode(201).body("books", notNullValue()).extract().response().asString();
        System.out.println("------------------------------");	
	}

}
