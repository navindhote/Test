import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

import org.testng.Assert;
import org.testng.annotations.Test;



import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class MethodChain {

	static String r;
	
	@Test
	public void getRequest() {
		
	RestAssured.baseURI="https://reqres.in/";
		 String R=given().log().all().header("Content-Type","application/json")
				 .when().get("/api/users?page=2").
		 then().log().all().assertThat().statusCode(200)
		 .body("page", equalTo(2))
		 .extract().response()
		 .asString();
System.out.println("------------------------------");
		System.out.println(R);
		JsonPath J=new JsonPath(R);
		r=J.getString("data[0].id");
		System.out.println(r);
		
	}
	
	
	@Test
	public void getRequest2() {
		
	RestAssured.baseURI="https://reqres.in/";
		 String R=given().log().all().header("Content-Type","application/json").when().get("/api/users/"+r).
		 then().log().all().assertThat().statusCode(200)
		 .body("data.id", notNullValue())
		 .extract().response()
		 .asString();
//System.out.println("------------------------------");
		System.out.println(R);
		JsonPath J=new JsonPath(R);
		String r=J.getString("data.id");
		System.out.println(r);
		Assert.assertEquals(r, "7");
		
	}
	
}
